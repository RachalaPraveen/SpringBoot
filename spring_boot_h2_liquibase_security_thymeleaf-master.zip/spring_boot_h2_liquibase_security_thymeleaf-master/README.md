This is a project that shows how to use spring boot in simple web app.

I use here:
- Spring boot:
  - data-jpa;
  - web;
  - thymeleaf;
  - security.
- H2 database (with ability to use web console http://localhost:8080/console (JDBC URL: jdbc:h2:mem:testdb));
- Liquibase.
