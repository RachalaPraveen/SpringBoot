package com.example.service;

import com.example.model.Product;

public interface ProductService extends BaseService<Product, Integer> {


}
