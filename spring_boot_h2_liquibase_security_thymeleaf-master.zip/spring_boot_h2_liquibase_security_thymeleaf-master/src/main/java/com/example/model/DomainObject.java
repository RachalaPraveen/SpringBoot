package com.example.model;

public interface DomainObject {

    Integer getId();

    void setId(Integer id);
}
