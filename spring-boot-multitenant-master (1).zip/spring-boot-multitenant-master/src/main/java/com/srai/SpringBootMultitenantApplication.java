package com.srai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMultitenantApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMultitenantApplication.class, args);
	}
}
